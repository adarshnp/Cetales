<?php
    session_start();
    $row = $_SESSION["question_record"];
    $user= $_SESSION['user'];  
    $servername = "localhost";
    $username = "cetales";
    $password = "cetales";
    $dbname = "cetales";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$answer=$_POST['answer'];
$sql = "INSERT INTO answers (QID,Answer,User,Dated)
VALUES (".$row['QID'].",'$answer','$user',now())";
if(mysqli_query($conn,$sql)){
    header("location:thread.php");
}
mysqli_close($conn);
?> 