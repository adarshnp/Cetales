<?php
    session_start();
?>
<!DOCTYPE html>
<html><head>
<title>My Web</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/style.css">
</head>
<body>
  <div class="header">
      <h1>CETales</h1>
      <p>An open forum for cetians</p>
  </div>
      
    <div class="topnav">
      <a href="dash.php">Home</a>
      <a href="#">Events</a>
      <a href="#">Contact Us</a>
      <a href="logout.php" style="float:right;">Log Out</a>
    </div>
      
    <div class="row">
      <div class="leftcolumn">
          <div class="card">
              <button class="button"><a href="ask.html">Ask A Question</a></button>
          </div>

<?php
    $row = $_SESSION["question_record"];
    echo "
    <div class='row'>
    <div class='number'>
      <div class='card'>
        <h1>Q:</h1>
      </div>
    </div>
    <div class='question'>
      <div class='card'>
        <h2>" . $row['Question'] . "</h2>
        <h5>asked by " . $row['User'] . "</h5>
        <h5>created on " . $row['Dated'] . "</h5>
      </div>
    </div>
  </div> ";  
?>
<h2>Answers</h2>
<?php
  $servername = "localhost";
  $username = "cetales";
  $password = "cetales";
  $dbname = "cetales";
  $conn = mysqli_connect($servername, $username, $password, $dbname);
  $query = "SELECT Answer,Dated,User FROM answers WHERE QID=".$row['QID'];
  $result = mysqli_query($conn,$query) or die(mysql_error());
  $count=0;
  if(mysqli_num_rows($result) > 0){
    while($rows = mysqli_fetch_array($result)){
      $count=$count + 1 ;
      echo "  <div class='row'>
              <div class='leftcard'>
                <div class='card'><p>
                asked by " . $rows['User'] . "<br/>
                created on " . $rows['Dated'] . "<br/></p>
                </div>
              </div>
              <div class='question'>
                <div class='card'>
                  <h3>" . $rows['Answer'] . "</h3>
                </div>
              </div>
            </div> ";
      }
    }
  else{
     echo
      "<div class='card'>
      <h2>Not Yet Answered! Be the first one to do</h2>
      </div>";
      }
  mysqli_close($conn);
?>

        <div class="card">
            <form action="answer.php" method="post">
                <label><h4>Your answer</h4></label>
                <input class="text_input" type="text" name="answer" value="enter answer here"><br/>
                <center><input class="button" type="submit" name="submit" value="Submit"></center>
            </form>
        </div>



        </div>
        <div class="rightcolumn">
          <div class="card">
            <h2>Developers</h2>
            <div class="fakeimg" style="height:100px;">Image</div>
            <p>Cet Software Developpment Commitee</p>
          </div>
          <div class="card">
            <h3>Popular Post</h3>
            <div class="fakeimg"><p>Image</p></div>
            <div class="fakeimg"><p>Image</p></div>
            <div class="fakeimg"><p>Image</p></div>
          </div>
          <div class="card">
            <h3>Follow Me</h3>
            <p>Some text..</p>
          </div>
        </div>
      </div>
      
      <div class="footer">
        <h2>CETales </h2>
      </div>
      
      </body>
      </html>
</html> 