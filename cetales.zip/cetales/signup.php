<?php
    ob_start();
    session_start();
    $msg = '';
    $servername = "localhost";
    $username = "cetales";
    $password = "cetales";
    $dbname = "cetales";
    $conn = mysqli_connect($servername, $username, $password, $dbname);
    if (isset($_POST['username'])){
    	$username = stripslashes($_POST['username']);
    	$username = mysqli_real_escape_string($conn,$username);
    	$password = stripslashes($_POST['password']);
        $password = mysqli_real_escape_string($conn,$password);
        $mail= $_POST['mail'];
        $query = "INSERT INTO users (Username,Password,Mail)
                  VALUES('$username','$password','$mail')";
	    $result = mysqli_query($conn,$query) or die(mysql_error());
        $_SESSION['user'] = $username;
   	    header("Location: dash.php");
    }
?>
