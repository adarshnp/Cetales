<?php
session_start();
$servername = "localhost";
$username = "cetales";
$password = "cetales";
$dbname = "cetales";
$user=$_SESSION['user'];
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
$question=$_POST['question'];
$sql = "INSERT INTO questions (Question,User,Dated) 
        VALUES ('$question','$user',now())";

if (mysqli_query($conn, $sql)) {
    header('location:dash.php');
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);
?> 