<?php
    session_start();
?>
<!DOCTYPE html>
<html><head>
<title>My Web</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/style.css">
</head>
<body>
  <div class="header">
      <h1>CETales</h1>
      <p>An open forum for cetians</p>
  </div>
      
    <div class="topnav">
      <a href="dash.php">Home</a>
      <a href="#">Events</a>
      <a href="#">Contact Us</a>
      <a href="logout.php" style="float:right;">Log Out</a>
      <?php
      $user=$_SESSION['user'];
       echo "<p style='float:right'>Hi,".$user."</p>";
      ?>
     
    </div>
      
    <div class="row">
      <div class="leftcolumn">
          <div class="card">
              <button class="button"><a href="ask.html">Ask A Question</a></button>
          </div>

<?php
  $servername = "localhost";
  $username = "cetales";
  $password = "cetales";
  $dbname = "cetales";
  $conn = mysqli_connect($servername, $username, $password, $dbname);
  $query = "SELECT QID,Question,Dated,User FROM questions ";
  $result = mysqli_query($conn,$query) or die(mysql_error());
  $count=0;
  if(mysqli_num_rows($result) > 0){
    while($rows = mysqli_fetch_array($result)){
      $count=$count + 1 ;
      $_SESSION["question_record"] = $rows;
      echo "<a href='thread.php'>
              <div class='row'>
                <div class='number'>
                  <div class='card'>
                    <h1>". $count ."</h1>
                  </div>
                </div>
                <div class='question'>
                  <div class='card'>
                    <h2>" . $rows['Question'] . "</h2>
                    <h5>asked by " . $rows['User'] . "</h5>
                    <h5>created on " . $rows['Dated'] . "</h5>
                  </div>
                </div>
              </div>
            </a>";
      }
    }
  else{
     echo
      "<div class='card'>
      <h2>No Questions Found</h2>
      </div>";
      }
  mysqli_close($conn);
?>




        </div>
        <div class="rightcolumn">
          <div class="card">
            <h2>Developers</h2>
            <div class="fakeimg" style="height:100px;">Image</div>
            <p>Cet Software Developpment Commitee</p>
          </div>
          <div class="card">
            <h3>Popular Post</h3>
            <div class="fakeimg"><p>Image</p></div>
            <div class="fakeimg"><p>Image</p></div>
            <div class="fakeimg"><p>Image</p></div>
          </div>
          <div class="card">
            <h3>Follow Me</h3>
            <p>Some text..</p>
          </div>
        </div>
      </div>
      
      <div class="footer">
        <h2>CETales </h2>
      </div>
      
      </body>
      </html>
</html> 